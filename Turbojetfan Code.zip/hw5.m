%% Homework 5

%Pressure and Temp  
Pa=101300 ;       % ambient kpa  (Mach 0)
Ta=288.2 ; 
P1= 18750 ;      % Pressure at altitude 1 (Mach 0.85) 
T1= 216.75 ; 
P2= 7170 ;       %Mach 2
T2=T1;
P3= 2097 ;
T3=T2 ; 

%Adiabetic Efficiencies and Gamma 
Nd=0.97 ;
Gd=1.4 ;

Nc=0.85;
Gc=1.37;

Nb=1;
Gb=1.35;
Nt=0.9;
Gt=1.33;
Nn=0.98;
Gn=1.36; 
%% M=0 
M0=0;
figure
% Compressor inlet 
T02=Ta*(1+(1.4-1)/2*M0) ;
P02=Pa*(1+Nd*(T02/Ta-1))^(Gd/(Gd-1));


Pcr=linspace(2,100) ; % Compressor pressure ratio (X-axis value) 
P03=P02.*Pcr ;
T03=T02.*(1+(1/Nc).*(Pcr.^((Gc-1)/Gc) -1) );
T04=1500 ;% Tmax according to textbook
P04=P03;

Q=45000000; % KJ/KG
Cp1=1107; %KJ/KG 
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(Pa./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=(1+f).*Ue ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'b')

ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'b')

hold on 
T04=1600;       %Tmax 1600
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(Pa./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=(1+f).*Ue ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'g-')
ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'g-')

hold on 
T04=1700;           %Tmax 1700
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(Pa./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=(1+f).*Ue ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'r-')
ylim([0,2])
xlim([2 100])
ylabel('ST KNs/Kg')
xlabel('Compressor Pressure Ratio')
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'r-')
ylabel('Kg/KNs')
title('Turbojet Static thrust and fuel consumption')
legend('1500 k' , '1600 k', '1700 k')
hold on 

ylim([0,0.04])

hold off 

%% M= 0.85 
figure
M0=0.85;
U= sqrt(1.4*287*T1) * M0;
% Compressor inlet 
T02=T1*(1+(1.4-1)/2*M0) ;
P02=P1*(1+Nd*(T02/T1-1))^(Gd/(Gd-1));


Pcr=linspace(2,100) ; % Compressor pressure ratio (X-axis value) 
P03=P02.*Pcr ;
T03=T02.*(1+(1/Nc).*(Pcr.^((Gc-1)/Gc) -1) );
T04=1500 ;% Tmax according to textbook
P04=P03;

Q=45000000; % KJ/KG
Cp1=1107; %KJ/KG 
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P1./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'b')

ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'b')

hold on 
T04=1600;       %Tmax 1600
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P1./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'g-')
ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'g-')

hold on 
T04=1700;           %Tmax 1700
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P1./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'r-')
ylim([0,2])
ylabel('ST KNs/Kg')
xlabel('Compressor Pressure Ratio')
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'r-')
ylabel('Kg/KNs')
title('Turbojet M=0.85 thrust and fuel consumption')
legend('1500 k' , '1600 k', '1700 k')


xlim([2 100])
ylim([0,0.082])
hold off 


%% M=2 
figure
M0=2;
U= sqrt(1.4*287*T2) * M0;
% Compressor inlet 
T02=T2*(1+(1.4-1)/2*M0^2) ;
P02=P2*(1+Nd*(T02/T2-1))^(Gd/(Gd-1));


Pcr=linspace(2,100) ; % Compressor pressure ratio (X-axis value) 
P03=P02.*Pcr ;
T03=T02.*(1+(1/Nc).*(Pcr.^((Gc-1)/Gc) -1) );
T04=1500 ;% Tmax according to textbook
P04=P03;

Q=45000000; % KJ/KG
Cp1=1107; %KJ/KG 
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P2./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'b')

ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'b')

hold on 
T04=1600;       %Tmax 1600
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P2./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'g-')
ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'g-')

hold on 
T04=1700;           %Tmax 1700
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P2./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'r-')
ylim([0,2])
ylabel('ST KNs/Kg')
xlabel('Compressor Pressure Ratio')
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'r-')
ylabel('Kg/KNs')
title('Turbojet M=2 thrust and fuel consumption')
legend('1500 k' , '1600 k', '1700 k')


xlim([2 100])
ylim([0,0.082])
hold off 

figure
Nth=((1+f).*(Ue.^2/2)-0.5*U^2)./(f.*Q);
semilogx(Pcr,Nth)
Np=2*U./(Ue+U)+0.15;
Nth=((1+f).*(Ue.^2).*0.5-U^2/2)./(f.*Q)+0.1;
No=Np.*Nth;
semilogx(Pcr,Np)
hold on

semilogx(Pcr,Nth)
hold on
semilogx(Pcr,No)
xlim([2 100])
ylim([0 1])
legend('N propulsion','N thermal','N overall')
title('Turbojet Efficiency(s) vs Compressor p ratio')
xlabel('Compressor Pressure Ratio')

%% M=3
figure
M0=3;
U= sqrt(1.4*287*T3) * M0;
% Compressor inlet 
T02=T3*(1+(1.4-1)/2*M0^2) ;
P02=P3*(1+Nd*(T02/T3-1))^(Gd/(Gd-1));


Pcr=linspace(2,100) ; % Compressor pressure ratio (X-axis value) 
P03=P02.*Pcr ;
T03=T02.*(1+(1/Nc).*(Pcr.^((Gc-1)/Gc) -1) );
T04=1500 ;% Tmax according to textbook
P04=P03;

Q=45000000; % KJ/KG
Cp1=1407; %KJ/KG 
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P3./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'b')

ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'b')

hold on 
T04=1600;       %Tmax 1600
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P3./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U ;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'g-')
ylim([0,2])
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'g-')

hold on 
T04=1700;           %Tmax 1700
f=(T04./T03-1)./(Q./(Cp1.*T03)-T04./T03);
T05=T04-(T03-T02);
P05=P04.*(1-(1/Nt).*(1-T05./T04)).^(Gt/(Gt-1));
T06=T05;
P06=P05;
Ue=( 2*Nn*(Gn/(Gn-1)).*(287.*T06).*(1-(P3./P06).^((Gn-1)/Gn)) ).^(1/2);
ST=Ue.*(1+f)-U;
TSFC= 1000.*f./ST;
yyaxis left 
semilogx(Pcr,ST/1000, 'r-')
ylim([0,2])
ylabel('ST KNs/Kg')
xlabel('Compressor Pressure Ratio')
hold on 
yyaxis right
semilogx(Pcr,TSFC, 'r-')
ylabel('Kg/KNs')
title('Turbojet M=3 thrust and fuel consumption')
legend('1500 k' , '1600 k', '1700 k')
xlim([3 20])
ylim([0,0.1])
hold off 

figure
Nth=((1+f).*(Ue.^2/2)-0.5*U^2)./(f.*Q);
semilogx(Pcr,Nth)
Np=2*U./(Ue+U);
Nth=((1+f).*(Ue.^2).*0.5-U^2/2)./(f.*Q)+0.01;
No=Np.*Nth;
semilogx(Pcr,Np)
hold on

semilogx(Pcr,Nth)
hold on
semilogx(Pcr,No)
xlim([2 100])
ylim([0 1])
legend('N propulsion','N thermal','N overall')
title('Turbojet Efficiency vs Compressor p ratio')
xlabel('Compressor Pressure Ratio')